////
////  Copyright © 2017 REA. All rights reserved.
////
//
//import Foundation
//import Quick
//import Nimble
//@testable import HomeTime
//
//class OldMockURLSessionDataTask: URLSessionDataTask {
//  override func resume() {
//    print("mock resume")
//  }
//}
//
//class OldMockURLSession: URLSession {
//  override func dataTask(with url: URL, completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTask {
//
//    let jsonString =  """
//{
//"responseObject" :
//  [
//    {
//    "PredictedArrivalDateTime": "/Date(1426821588000+1100)/"
//    }
//  ]
//}
//"""
//    let data = jsonString.data(using: .utf8)!
//    completionHandler(data, nil, nil)
//
//    return OldMockURLSessionDataTask()
//  }
//}
//
//// MARK: -
//
//class HomeTimeViewControllerSpec: QuickSpec {
//  
//  override func spec() {
//    describe("HomeTimeViewController") {
//      var homeTimeViewController: HomeTimeViewController?
//
//      beforeEach {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        homeTimeViewController = storyboard.instantiateViewController(withIdentifier: "homeTimeViewController") as? HomeTimeViewController
//        homeTimeViewController?.loadViewIfNeeded()
//        homeTimeViewController?.token = "theToken"
//      }
//
//      it("should have sections for north and south") {
//        let sections = homeTimeViewController?.tramTimesTable.numberOfSections
//
//        expect(sections) == 2
//      }
//
//      it("should initialize no tram data") {
//        let tramsTable = homeTimeViewController?.tramTimesTable
//
//        let north = tramsTable?.numberOfRows(inSection: 0)
//        expect(north) == 1
//
//        let placeholderCell = tramsTable?.cellForRow(at: IndexPath(row: 0, section: 0))
//        let placeholder = placeholderCell?.textLabel?.text
//        expect(placeholder?.hasPrefix("No upcoming trams")) == true
//
//        let south = tramsTable?.numberOfRows(inSection: 1)
//        expect(south) == 1
//      }
//
//      it("should display arriveDateTime on table after load api response") {
//        homeTimeViewController?.session = OldMockURLSession()
//        homeTimeViewController?.loadTramData()
//
//        let tramsTable = homeTimeViewController?.tramTimesTable
//        let northTramCell = tramsTable?.cellForRow(at: IndexPath(row: 0, section: 0))
//        expect(northTramCell?.textLabel?.text) == "14:19"
//
//        let southTramCell = tramsTable?.cellForRow(at: IndexPath(row: 0, section: 1))
//        expect(southTramCell?.textLabel?.text) == "14:19"
//      }
//    }
//
//  }
//}
