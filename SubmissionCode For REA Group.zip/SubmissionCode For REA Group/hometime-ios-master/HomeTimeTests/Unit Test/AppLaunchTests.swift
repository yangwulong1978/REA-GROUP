//
//  AppLaunchTests.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import Foundation

import XCTest
@testable import HomeTime
class AppLaunchTests: XCTestCase {
    func test_emptyJustSoWeHaveAPassingTest() {
        
        
    }
    

}

