//
//  HttpClient2Tests.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import XCTest
@testable import HomeTime
class HttpClient2Tests: XCTestCase {
    var httpClient: HttpClient!
    var session = MockURLSession()
    
    override func setUp() {
        super.setUp()
        session = MockURLSession()
        httpClient = HttpClient(session: session)
    }
    
    override func tearDown() {
        super.tearDown()
    }
    func test_get_request_with_URL1(){
        guard let url = URL(string: "https://MOCKURL") else {
            fatalError("URL can't be empty")
        }
        httpClient.get(url: url) { (data, response,error) in
            // Return data
        }
        XCTAssertEqual(
            session.dataTaskArgsRequest.first,
            URLRequest(url: url),
            "request")
    }
    func test_get_request_with_URL2() {
        guard let url = URL(string: "https://MOCKURL") else {
            fatalError("URL can't be empty")
        }
        httpClient.get(url: url) { (data, response,error) in
            // Return data
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: (\(httpResponse.statusCode))")
                // do stuff.
            }
        }
        
        XCTAssert(session.lastURL == url)
    }
    func test_dataTask_hasCalled(){
        guard let url = URL(string: "https://MOCKURL") else {
            fatalError("URL can't be empty")
        }
        httpClient.get(url: url) { (data, response,error) in
            // Return data
        }
        XCTAssertEqual(session.dataTaskCallCount, 1, "call count")
    }
    
    
    func test_get_resume_called() {
        let dataTask = MockURLSessionDataTask()
        session.nextDataTask = dataTask
        guard let url = URL(string: "https://MOCKURL") else {
            fatalError("URL can't be empty")
        }
        httpClient.get(url: url) { (data, response,error) in
            // Return data
        }
        
        XCTAssert(dataTask.resumeWasCalled)
    }
    
    func test_get_should_return_data() {
        let expectedData = getMockTramNorthStopJsonData()
        session.nextData = expectedData
        var actualData: Data?
        
        httpClient.get(url: URL(string: "http://MOCKURL")!) { (data, response,error) in
            actualData = data
        }
        XCTAssertNotNil(actualData)
    }
    
    
    
}
