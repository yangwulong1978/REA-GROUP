//
//  CommonLibTests.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import XCTest
@testable import HomeTime
import ViewControllerPresentationSpy
class CommonLibTests: XCTestCase {
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func test_SaveDeviceToken(){
        let defaults = MockUserDefaults()
        let value = "8c48d7b8-5b9f-40b9-93c0-222c2c480135"
        defaults.set(String(describing: value), forKey:CommonLib.tokenKey )
        let result =  defaults.string(forKey: CommonLib.tokenKey)!
        
        XCTAssertEqual(value, result)
        
    }
    func test_uiAlertPopupController_CanPopUp(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let homeTimeViewController = storyboard.instantiateViewController(
            identifier: String(describing: HomeTimeViewController.self))
        homeTimeViewController.loadViewIfNeeded()
        let alertVerifier = AlertVerifier()
        
        CommonLib.uiAlertPopupController(title: "Information Message", message: "Mock Message", viewController: homeTimeViewController, displaySeconds: 2){}
        
        alertVerifier.verify(
            title: "Information Message",
            message: "Mock Message",
            animated: true,
            actions: [
                //                    .cancel("Cancel"),
                //                    .default("OK"),
            ],
            presentingViewController: homeTimeViewController
        )
        
        XCTAssertEqual(alertVerifier.message ,"Mock Message")
    }
    
    func test_uiAlertPopupController_CanDisappeared(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let homeTimeViewController = storyboard.instantiateViewController(
            identifier: String(describing: HomeTimeViewController.self))
        homeTimeViewController.loadViewIfNeeded()
        
        var hasDisappeared = false
        
        let exp = expectation(description: "UIAlertController disppearing")
        CommonLib.uiAlertPopupController(title: "Information Message", message: "Mock Message", viewController: homeTimeViewController, displaySeconds: 1){
            
            hasDisappeared = true
            exp.fulfill()
        }
        
        waitForExpectations(timeout: 2,handler: nil)
        
        XCTAssertTrue(hasDisappeared)
    }
    
    //Mark: Test DotNetDateConverter
    
    func test_dateFromDotNetFormattedDateString_invalidDataString1_returnNil(){
        let result = CommonLib.dateFromDotNetFormattedDateString("dummyString")
        XCTAssertNil(result)
    }
    
    func test_dateFromDotNetFormattedDateString_invalidDataString2_returnNil(){
        let result = CommonLib.dateFromDotNetFormattedDateString( "/Date(ABCDEFGHIJK+1100)/")
        XCTAssertNil(result)
    }
    func test_dateFromDotNetFormattedDateString_validDataString_returnDataString(){
        let result = CommonLib.dateFromDotNetFormattedDateString("/Date(1615068900000+1100)/")
        XCTAssertNotNil(result)
    }
    func test_formattedDateFromString_inputValidDataString_returnDataString(){
        let result = CommonLib.formattedDateFromString("/Date(1426821588000+1100)/")
        XCTAssertEqual(result, "14:19 PM")
    }
    func test_formattedDateFromString_inputValidDataString_returnEmptyString(){
        let result = CommonLib.formattedDateFromString("dummyString")
        XCTAssertEqual(result, "")
    }
    func test_minutesBetweenDates__inputValidDataString_returnDataString(){
        let result = CommonLib.minutesBetweenDates("/Date(1615068900000+1100)/",Date())
        XCTAssertTrue(result.count > 0)
    }
    func test_minutesBetweenDates__inputInValidDataString_returnEmptyString(){
        let result = CommonLib.minutesBetweenDates("dummyString",Date())
        XCTAssertTrue(result.count == 0)
    }
    func test_minutesBetweenDates__inputEmptyDataString_returnEmptyString(){
        let result = CommonLib.minutesBetweenDates("",Date())
        XCTAssertTrue(result.count == 0)
    }
    
}
