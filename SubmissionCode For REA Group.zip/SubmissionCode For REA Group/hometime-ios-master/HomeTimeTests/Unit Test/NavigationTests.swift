//
//  TestExample.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import XCTest
@testable import HomeTime
class NavigationTests: XCTestCase {
    
    
    
    func test_navigation_shouldPushHomeTimeViewControoler() throws {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let  homeTimeViewController = storyboard.instantiateViewController(
            identifier: String(describing: HomeTimeViewController.self)) as! HomeTimeViewController
        
        homeTimeViewController.loadViewIfNeeded()
        excuteRunLoop()
        let navigation = UINavigationController(rootViewController: homeTimeViewController)
        
        XCTAssertEqual(navigation.viewControllers.count, 1)
        
    }
    
    
    
}
