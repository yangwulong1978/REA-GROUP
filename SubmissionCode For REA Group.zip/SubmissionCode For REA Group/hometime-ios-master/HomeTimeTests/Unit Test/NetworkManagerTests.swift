//
//  NetworkManagerTests.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import XCTest
import SwiftyJSON
@testable import HomeTime

class NetworkManagerTests: XCTestCase {
    
    var networkManager:NetworkManager! = nil
    override  func setUp() {
        networkManager = NetworkManager()
    }
    override  func tearDown() {
        networkManager = nil
    }
    func test_getTokenUrl_returnURL(){
        XCTAssertNotNil(networkManager.getDeviceTokenUrl())
    }
    func test_getStopUrl_returnURL(){
        let url =  networkManager.getNextPredictedRoutesCollectionUrl(stopId: getMockNorthStopId(), token:  getMockDeviceTokenValue())
        XCTAssertNotNil(url)
    }
    
    // Mark: Mock to Call getDeviceToken webservice
    func test_getDeviceToken_Success() throws{
        
        let session = MockURLSession()
        session.nextData = getMockDeviceTokenJsonData()
        session.responseCode = 200
        networkManager.session = session
        CommonLib.defaults = MockUserDefaults()
        
        let exp = expectation(description: "fetch device token data")
        networkManager.getDeviceToken(){
            exp.fulfill()
        }
        waitForExpectations(timeout: 1,handler: nil)
        XCTAssertNotNil(CommonLib.readTokenValue())
        
    }
    
    func test_getDeviceToken_wrongResponseCode_Fail() throws{
        
        let session = MockURLSession()
        session.nextData = getMockDeviceTokenJsonData()
        session.responseCode = 400
        networkManager.session = session
        CommonLib.defaults = MockUserDefaults()
        
        let exp = expectation(description: "fetch device token data")
        networkManager.getDeviceToken(){
            exp.fulfill()
        }
        waitForExpectations(timeout: 1,handler: nil)
        XCTAssertNil(CommonLib.readTokenValue())
        
    }
    
    func test_getDeviceToken_withError_Fail() throws{
        
        let session = MockURLSession()
        session.nextData = getMockDeviceTokenJsonData()
        session.responseCode = 200
        session.nextError = MockError(message: "MOCK ERROR")
        networkManager.session = session
        CommonLib.defaults = MockUserDefaults()
        
        let exp = expectation(description: "fetch device token data")
        networkManager.getDeviceToken(){
            exp.fulfill()
        }
        waitForExpectations(timeout: 1,handler: nil)
        XCTAssertNil(CommonLib.readTokenValue())
        
    }
    
    
    func test_getDeviceToken_withErrorMessage_Fail() throws{
        
        let session = MockURLSession()
        session.nextData = getMockDeviceTokenJsonDataWithErrorMessage()
        session.responseCode = 200
        networkManager.session = session
        CommonLib.defaults = MockUserDefaults()
        
        let exp = expectation(description: "fetch device token data")
        networkManager.getDeviceToken(){
            exp.fulfill()
        }
        waitForExpectations(timeout: 1,handler: nil)
        XCTAssertNil(CommonLib.readTokenValue())
        
    }
    
    // Mark: Mock to Call loadStopTramData webservice
    
    func test_loadStopTramData_getNorthStopData_Success() throws{
        
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        let session = MockURLSession()
        session.nextData = getMockTramNorthStopJsonData()
        session.responseCode = 200
        networkManager.session = session
        
        let exp = expectation(description: "fetch North Stop TramData")
        networkManager.loadStopTramData(stop:STOP.north.rawValue,stopId:  networkManager.getNorthStopId(), token: CommonLib.readTokenValue()!){(data,response,error) in
            
            let swiftJsonData = JSON(data!)["responseObject"][0]
            if data != nil{
                XCTAssertNotNil(swiftJsonData["RoutNo"])
                XCTAssertNotNil(swiftJsonData["PredictedArrivalDateTime"])
                XCTAssertNotNil(swiftJsonData["VehicleNo"])
                XCTAssertNotNil(swiftJsonData["Destination"])
                XCTAssertNotNil(swiftJsonData["TimeLeft"])
            }
            
            exp.fulfill()
        }
        
        waitForExpectations(timeout: 1,handler: nil)
        
    }
    
    func test_loadStopTramData_getSouthStopData_Success() throws{
        
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        let session = MockURLSession()
        session.nextData = getMockTramSouthStopJsonData()
        session.responseCode = 200
        networkManager.session = session
        
        let exp = expectation(description: "fetch South Stop TramData")
        networkManager.loadStopTramData(stop:STOP.north.rawValue,stopId:  networkManager.getSouthStopId(), token: CommonLib.readTokenValue()!){(data,response,error) in
            
            if data != nil{
                let swiftJsonData = JSON(data!)["responseObject"][0]
                
                XCTAssertNotNil(swiftJsonData["RoutNo"])
                XCTAssertNotNil(swiftJsonData["PredictedArrivalDateTime"])
                XCTAssertNotNil(swiftJsonData["VehicleNo"])
                XCTAssertNotNil(swiftJsonData["Destination"])
                XCTAssertNotNil(swiftJsonData["TimeLeft"])
                
            }
            exp.fulfill()
        }
        waitForExpectations(timeout: 1,handler: nil)
    }
    
    func test_loadStopTramData_getSouthStopData_withWrongResponseCode_Fail() throws{
        
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        let session = MockURLSession()
        session.nextData = getMockTramSouthStopJsonData()
        //wrong responseCode
        session.responseCode = 400
        networkManager.session = session
        let exp = expectation(description: "fetch South Stop TramData")
        
        networkManager.loadStopTramData(stop:STOP.north.rawValue,stopId:  networkManager.getSouthStopId(), token: CommonLib.readTokenValue()!){(data,response,error) in
            
            if response != nil{
                let httpResponse = response as! HTTPURLResponse
                XCTAssertEqual(httpResponse.statusCode, 400)
            }
            exp.fulfill()
        }
        
        waitForExpectations(timeout: 1,handler: nil)
        
    }
    
    func test_loadStopTramData_getSouthStopData_withError_Fail() throws{
        
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        let session = MockURLSession()
        session.nextData = getMockTramSouthStopJsonData()
        session.nextError = MockError(message: "MOCK ERROR")
        networkManager.session = session
        let exp = expectation(description: "fetch South Stop TramData")
        networkManager.loadStopTramData(stop:STOP.north.rawValue,stopId:  networkManager.getSouthStopId(), token: CommonLib.readTokenValue()!){(data,response,error) in
            XCTAssertNotNil(error)
            exp.fulfill()
        }
        waitForExpectations(timeout: 1,handler: nil)
        
    }
    
}
