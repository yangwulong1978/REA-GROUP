//
//  HomeTimeViewControllerTests.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import XCTest
@testable import HomeTime
class HomeTimeViewControllerTests: XCTestCase {
    
    private var  homeTimeViewController: HomeTimeViewController!
    override  func setUp() {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        homeTimeViewController = storyboard.instantiateViewController(
            identifier: String(describing: HomeTimeViewController.self))
        CommonLib.defaults = MockUserDefaults()
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        homeTimeViewController.networkManager = NetworkManager()
        
        
        
    }
    override  func tearDown() {
        
        homeTimeViewController = nil
    }
    func test_homeTimeViewController_loading(){
        
        homeTimeViewController.loadViewIfNeeded()
        XCTAssertNotNil(homeTimeViewController.tramTimeTable)
    }
    
    //Mark:Test Outlet Connections
    
    func test_outlets_shouldBeConnected(){
        homeTimeViewController.loadViewIfNeeded()
        XCTAssertNotNil(homeTimeViewController.clearBarButton,"clearBarButton")
        XCTAssertNotNil(homeTimeViewController.refreshBarButton,"refreshBarButton")
        XCTAssertNotNil(homeTimeViewController.activityIndicator,"activityIndicator")
        XCTAssertNotNil(homeTimeViewController.tramTimeTable,"tramTimeTable")
    }
    
    func test_tableViewCell_shouldBeConnected(){
        
        let session = MockURLSession()
        //Load North Stop Tram Data
        session.nextData = getMockTramNorthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            
            homeTimeViewController.loadTramData(describe: "LoadingData") {
                DispatchQueue.main.async {
                    exp.fulfill()
                }
                
            }
            
        }
        waitForExpectations(timeout: 1,handler: nil)
        
        let indexPath = IndexPath(row: 0, section: 0)
        let cell = homeTimeViewController.tramTimeTable.cellForRow(at: indexPath) as! HomeTimeTableViewCell
        XCTAssertNotNil(cell.arrivalTimeLbl,"arrivalTimeLbl")
        XCTAssertNotNil(cell.timeLeftLbl,"timeLeftLbl")
        
    }
    //MARK: Test TableView operation
    func test_tableViewDelegates_shouldBeConnected() {
        homeTimeViewController.loadViewIfNeeded()
        XCTAssertNotNil(homeTimeViewController.tramTimeTable.dataSource, "dataSource")
        XCTAssertNotNil(homeTimeViewController.tramTimeTable.delegate, "delegate")
    }
    
    func test_numberOfRowsInSection0_shouldBeGreateEqualThan3() {
        
        let session = MockURLSession()
        session.nextData = getMockTramNorthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            homeTimeViewController.loadTramData(describe: "LoadingData") {
                DispatchQueue.main.async {
                    exp.fulfill()
                }
                
            }
        }
        
        waitForExpectations(timeout: 1,handler: nil)
        XCTAssertTrue(numberOfRows(in: homeTimeViewController.tramTimeTable,section: 0) != nil)
        XCTAssertTrue(numberOfRows(in: homeTimeViewController.tramTimeTable,section: 0)! >= 3)
    }
    func test_numberOfRowsInSection1_shouldBeGreateEqualThan3() {
        let session = MockURLSession()
        session.nextData = getMockTramSouthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            homeTimeViewController.loadTramData(describe: "LoadingData") {
                DispatchQueue.main.async {
                    exp.fulfill()
                }
                
            }
        }
        
        waitForExpectations(timeout: 1,handler: nil)
        XCTAssertTrue(numberOfRows(in: homeTimeViewController.tramTimeTable,section: 1) != nil)
        XCTAssertTrue(numberOfRows(in: homeTimeViewController.tramTimeTable,section: 1)! >= 3)
    }
    func test_cellForRowAt_inSection0_withRow0_shouldSetCell_ArrivalTimeLabel() {
        
        let session = MockURLSession()
        session.nextData = getMockTramNorthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            
            homeTimeViewController.loadTramData(describe: "LoadingData") {
                DispatchQueue.main.async {
                    exp.fulfill()
                }
            }
        }
        waitForExpectations(timeout: 1,handler: nil)
        let cell = (homeTimeViewController.tramTimeTable.dataSource?.tableView(
                        homeTimeViewController.tramTimeTable, cellForRowAt: IndexPath(row: 0, section: 0))) as! HomeTimeTableViewCell
        
        XCTAssertTrue(cell.arrivalTimeLbl.text!.count > 0 )
    }
    func test_cellForRowAt_inSection0_withRow0_shouldSetCell_TimeLeftLabel() {
        
        let session = MockURLSession()
        session.nextData = getMockTramNorthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            homeTimeViewController.loadTramData(describe: "LoadingData") {
                DispatchQueue.main.async {
                    exp.fulfill()
                }
            }
        }
        waitForExpectations(timeout: 1,handler: nil)
        let cell = (homeTimeViewController.tramTimeTable.dataSource?.tableView(
                        homeTimeViewController.tramTimeTable, cellForRowAt: IndexPath(row: 0, section: 0))) as! HomeTimeTableViewCell
        
        XCTAssertTrue(cell.timeLeftLbl.text!.count > 0 )
    }
    
    func test_cellForRowAt_inSection1_withRow0_shouldSetCell_ArrivalTimeLabel() {
        let session = MockURLSession()
        session.nextData = getMockTramSouthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            homeTimeViewController.loadTramData(describe: "LoadingData") {
                DispatchQueue.main.async {
                    exp.fulfill()
                }
            }
        }
        waitForExpectations(timeout: 1,handler: nil)
        let cell = (homeTimeViewController.tramTimeTable.dataSource?.tableView(
                        homeTimeViewController.tramTimeTable, cellForRowAt: IndexPath(row: 0, section: 0))) as! HomeTimeTableViewCell
        
        XCTAssertTrue(cell.arrivalTimeLbl.text!.count > 0 )
    }
    
    func test_cellForRowAt_inSection1_withRow0_shouldSetCell_TimeLeftLabel() {
        
        let session = MockURLSession()
        session.nextData = getMockTramSouthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            
            homeTimeViewController.loadTramData(describe: "LoadingData") {
                DispatchQueue.main.async {
                    exp.fulfill()
                }
                
            }
        }
        waitForExpectations(timeout: 1,handler: nil)
        let cell = (homeTimeViewController.tramTimeTable.dataSource?.tableView(
                        homeTimeViewController.tramTimeTable, cellForRowAt: IndexPath(row: 0, section: 0))) as! HomeTimeTableViewCell
        
        XCTAssertTrue(cell.timeLeftLbl.text!.count > 0 )
    }
    func test_didSelectRow_WithSection0_withRow1() {
        
        let session = MockURLSession()
        session.nextData = getMockTramNorthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            homeTimeViewController.loadTramData(describe: "LoadingData") {
                DispatchQueue.main.async {
                    exp.fulfill()
                }
            }
        }
        waitForExpectations(timeout: 1,handler: nil)
        
        let session1 = MockURLSession()
        session1.nextData = getMockTramSouthStopJsonData()
        session1.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp1 = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            
            homeTimeViewController.loadTramData(describe: "LoadingData") {
                DispatchQueue.main.async {
                    exp1.fulfill()
                }
                
            }
        }
        waitForExpectations(timeout: 1,handler: nil)
        didSelectRow(in: self.homeTimeViewController.tramTimeTable, row: 1,section: 0)
        
        XCTAssertTrue(homeTimeViewController.hasSelectedRow)
        
        
    }
    //MARKS: BarButton Operation
    func test_clearBarButton_tappingButton() {
        
        let session = MockURLSession()
        session.nextData = getMockTramNorthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            
            homeTimeViewController.loadTramData(describe: "LoadingData") {
                DispatchQueue.main.async {
                    // self.homeTimeViewController.tramTimeTable.reloadData()
                    exp.fulfill()
                    tap(self.homeTimeViewController.clearBarButton)
                }
            }
        }
        
        waitForExpectations(timeout: 1,handler: nil)
        XCTAssertEqual(numberOfRows(in: homeTimeViewController.tramTimeTable,section: 0), 0)
        
    }
    
    func test_refreshBarButton_tappingButton() {
        
        homeTimeViewController.loadViewIfNeeded()
        tap(self.homeTimeViewController.refreshBarButton)
        
        XCTAssertEqual(homeTimeViewController.loading ,true)
    }
    
    // Mark: Mock to Call webservice
    
    func test_callWebservice_getNorthStopTramData_Success() throws{
        
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        let session = MockURLSession()
        
        session.nextData = getMockTramNorthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        
        let exp = expectation(description: "fetch North Stop TramData")
        homeTimeViewController.loadTramData(describe: "LoadingData") {
            DispatchQueue.main.async {
                exp.fulfill()
            }
        }
        waitForExpectations(timeout: 1,handler: nil)
        XCTAssertTrue(homeTimeViewController.northTramsArr.count >= 3 )
        
    }
    
    
    func test_callWebservice_getNorthStopTramData_withWrongResponseCode_Fail() throws{
        homeTimeViewController.loadViewIfNeeded()
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        let session = MockURLSession()
        session.nextData = getMockTramNorthStopJsonData()
        
        // wrong responseCode
        session.responseCode = 400
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        
        let exp = expectation(description: "fetch North Stop TramData")
        homeTimeViewController.loadTramData(describe: "LoadingData") {
            DispatchQueue.main.async {
                exp.fulfill()
            }
        }
        waitForExpectations(timeout: 1,handler: nil)
        XCTAssertTrue(homeTimeViewController.northTramsArr.count == 0 )
        
    }
    
    func test_callWebservice_getNorthStopTramData_withError_Fail() throws{
        
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        let session = MockURLSession()
        session.nextData = getMockTramNorthStopJsonData()
        
        // wrong responseCode
        session.responseCode = 200
        session.nextError = MockError(message: "MOCK ERROR")
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        
        let exp = expectation(description: "fetch northStopTramData")
        homeTimeViewController.loadTramData(describe: "LoadingData") {
            DispatchQueue.main.async {
                exp.fulfill()
            }
        }
        waitForExpectations(timeout: 1,handler: nil)
        XCTAssertTrue(homeTimeViewController.northTramsArr.count == 0 )
        
    }
    
    
    
    func test_callWebservice_getNorthStopTramDataWithErrorMessage_Fail() throws{
        homeTimeViewController.loadViewIfNeeded()
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        
        let session = MockURLSession()
        
        //pass errormessage in data
        session.nextData = getMockTramNorthStopJsonDataWithErrorMessage()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "fetch North Stop TramData")
        homeTimeViewController.loadTramData(describe: "LoadingData") {
            DispatchQueue.main.async {
                exp.fulfill()
            }
        }
        waitForExpectations(timeout: 1,handler: nil)
        
        //did not receive update northTramsArr
        XCTAssertTrue(homeTimeViewController.northTramsArr.count == 0 )
        
    }
    
    
    func test_NoTokenWhenScreenLoaded_toCallFetchTokenWebservice_getDeviceToken() throws{
        
        CommonLib.defaults.set(nil, forKey: CommonLib.tokenKey)
        let token = CommonLib.readTokenValue()
        if token == nil {
            let session = MockURLSession()
            session.nextData = getMockDeviceTokenJsonData()
            session.responseCode = 200
            homeTimeViewController.networkManager.session = session
        }
        homeTimeViewController.loadViewIfNeeded()
        let exp = expectation(description: "fetch North Stop TramData")
        
        homeTimeViewController.loadTramData(describe: "LoadTramData") {
            exp.fulfill()
        }
        waitForExpectations(timeout: 1,handler: nil)
        
        XCTAssertNotNil(CommonLib.readTokenValue())
        
    }
    
    //    //Mark:  Test ScheduleTime
    //
    //    func test_scheduledTimerToCallWebService_called(){
    //
    //        let session = MockURLSession()
    //        session.nextData = tramNorthStopJsonData()
    //        session.responseCode = 200
    //        homeTimeViewController.networkManager.session = session
    //        homeTimeViewController.loadViewIfNeeded()
    //        let exp = expectation(description: "Loading Data")
    //        homeTimeViewController.withTimeInterval = 1
    //
    //
    //        homeTimeViewController.scheduledTimerToCallWebService(second: homeTimeViewController.withTimeInterval){
    //
    //            exp
    //        }
    //    }
}
