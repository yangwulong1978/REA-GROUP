//
//  TestHelpers.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import Foundation
import UIKit
@testable import HomeTime

func numberOfRows(in tableView: UITableView, section: Int = 0) -> Int? {
    tableView.dataSource?.tableView(
        tableView, numberOfRowsInSection: section)
}

func cellForRow(in tableView: UITableView, row: Int, section: Int = 0)
-> UITableViewCell? {
    tableView.dataSource?.tableView(
        tableView, cellForRowAt: IndexPath(row: row, section: section))
}

func didSelectRow(in tableView: UITableView, row: Int, section: Int = 0) {
    tableView.delegate?.tableView?(
        tableView, didSelectRowAt: IndexPath(row: row, section: section))
}


func tap(_ button: UIBarButtonItem) {
    _ = button.target?.perform(button.action, with: nil)
}



// Sometime unit test calls UIKit but don't see the expected results,try executing the run loop before assertion
func excuteRunLoop() {
    RunLoop.current.run(until:Date())
}
