//
//  MockTestHelp.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import Foundation
@testable import HomeTime

//MARK: MOCK Network Call
public class MockURLSession: URLSessionProtocol {
    
    var nextDataTask = MockURLSessionDataTask()
    var nextData: Data?
    var nextError: Error?
    
    var responseCode:Int = 200
    private (set) var lastURL: URL?
    
    var dataTaskCallCount = 0
    var dataTaskArgsRequest: [URLRequest] = []
    
    
   
    func response(statusCode: Int) -> HTTPURLResponse? {
        HTTPURLResponse(url: URL(string: "http://MOCKUPURL")!,
                        statusCode: statusCode, httpVersion: nil, headerFields: nil)
    }
    public func dataTask(with request: URLRequest, completionHandler: @escaping DataTaskResult) -> URLSessionDataTaskProtocol {
        lastURL = request.url
        dataTaskCallCount += 1
        dataTaskArgsRequest.append(request)
        
        completionHandler(nextData, response(statusCode: responseCode), nextError)
        
        return nextDataTask
        
    }
    
}

public class MockURLSessionDataTask: URLSessionDataTaskProtocol {
    private (set) var resumeWasCalled = false
    
    public func resume() {
        resumeWasCalled = true
    }
}

struct MockError: LocalizedError {
    let message: String
    
    var errorDescription: String? { message }
}


//Mark:  Mock user defaults
public class MockUserDefaults: UserDefaultsProtocol {
    
    
    var strings: [String: String] = [:]
    public func set(_ value: Any?, forKey: String) {
        if value == nil{
            strings[forKey] = nil
            return
        }
        strings[forKey] = String(describing: value!)
    }
    
    public func string(forKey defaultName: String) -> String? {
        return strings[defaultName] == nil ? nil: strings[defaultName]!
    }
    
    
    
}




