//
//  TestData.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import Foundation

func getMockTramNorthStopJsonData() -> Data {
    """
 {
     "errorMessage": null,
     "hasError": false,
     "hasResponse": true,
     "responseObject": [
         {
             "__type": "NextPredictedRoutesCollectionInfo",
             "AirConditioned": false,
             "Destination": "North Richmond",
             "DisplayAC": false,
             "DisruptionMessage": {
                 "DisplayType": "Text",
                 "MessageCount": 0,
                 "Messages": []
             },
             "HasDisruption": false,
             "HasSpecialEvent": true,
             "HeadBoardRouteNo": "78",
             "InternalRouteNo": 78,
             "IsLowFloorTram": false,
             "IsTTAvailable": true,
             "PredictedArrivalDateTime": "/Date(1615168038000+1100)/",
             "RouteNo": "78",
             "SpecialEventMessage": "Labour Day Public Holiday today: trams run to a Saturday frequency with no Night Network. Info: yarratrams.com.au",
             "TripID": 0,
             "VehicleNo": 263
         },
         {
             "__type": "NextPredictedRoutesCollectionInfo",
             "AirConditioned": false,
             "Destination": "North Richmond",
             "DisplayAC": false,
             "DisruptionMessage": {
                 "DisplayType": "Text",
                 "MessageCount": 0,
                 "Messages": []
             },
             "HasDisruption": false,
             "HasSpecialEvent": true,
             "HeadBoardRouteNo": "78",
             "InternalRouteNo": 78,
             "IsLowFloorTram": false,
             "IsTTAvailable": true,
             "PredictedArrivalDateTime": "/Date(1615169532000+1100)/",
             "RouteNo": "78",
             "SpecialEventMessage": "Labour Day Public Holiday today: trams run to a Saturday frequency with no Night Network. Info: yarratrams.com.au",
             "TripID": 0,
             "VehicleNo": 249
         },
         {
             "__type": "NextPredictedRoutesCollectionInfo",
             "AirConditioned": false,
             "Destination": "North Richmond",
             "DisplayAC": false,
             "DisruptionMessage": {
                 "DisplayType": "Text",
                 "MessageCount": 0,
                 "Messages": []
             },
             "HasDisruption": false,
             "HasSpecialEvent": true,
             "HeadBoardRouteNo": "78",
             "InternalRouteNo": 78,
             "IsLowFloorTram": false,
             "IsTTAvailable": true,
             "PredictedArrivalDateTime": "/Date(1615170120000+1100)/",
             "RouteNo": "78",
             "SpecialEventMessage": "Labour Day Public Holiday today: trams run to a Saturday frequency with no Night Network. Info: yarratrams.com.au",
             "TripID": 0,
             "VehicleNo": 291
         }
     ],
     "timeRequested": "/Date(1615167519571+1100)/",
     "timeResponded": "/Date(1615167519649+1100)/",
     "webMethodCalled": "GetNextPredictedRoutesCollection"
 }
""".data(using: .utf8)!
}


func getMockTramNorthStopJsonDataWithErrorMessage() -> Data {
    """
 {
     "errorMessage": "Mock Error Message",
     "hasError": false,
     "hasResponse": true,
     "responseObject": [
         {
             "__type": "NextPredictedRoutesCollectionInfo",
             "AirConditioned": false,
             "Destination": "North Richmond",
             "DisplayAC": false,
             "DisruptionMessage": {
                 "DisplayType": "Text",
                 "MessageCount": 0,
                 "Messages": []
             },
             "HasDisruption": false,
             "HasSpecialEvent": true,
             "HeadBoardRouteNo": "78",
             "InternalRouteNo": 78,
             "IsLowFloorTram": false,
             "IsTTAvailable": true,
             "PredictedArrivalDateTime": "/Date(1615168038000+1100)/",
             "RouteNo": "78",
             "SpecialEventMessage": "Labour Day Public Holiday today: trams run to a Saturday frequency with no Night Network. Info: yarratrams.com.au",
             "TripID": 0,
             "VehicleNo": 263
         },
         {
             "__type": "NextPredictedRoutesCollectionInfo",
             "AirConditioned": false,
             "Destination": "North Richmond",
             "DisplayAC": false,
             "DisruptionMessage": {
                 "DisplayType": "Text",
                 "MessageCount": 0,
                 "Messages": []
             },
             "HasDisruption": false,
             "HasSpecialEvent": true,
             "HeadBoardRouteNo": "78",
             "InternalRouteNo": 78,
             "IsLowFloorTram": false,
             "IsTTAvailable": true,
             "PredictedArrivalDateTime": "/Date(1615169532000+1100)/",
             "RouteNo": "78",
             "SpecialEventMessage": "Labour Day Public Holiday today: trams run to a Saturday frequency with no Night Network. Info: yarratrams.com.au",
             "TripID": 0,
             "VehicleNo": 249
         },
         {
             "__type": "NextPredictedRoutesCollectionInfo",
             "AirConditioned": false,
             "Destination": "North Richmond",
             "DisplayAC": false,
             "DisruptionMessage": {
                 "DisplayType": "Text",
                 "MessageCount": 0,
                 "Messages": []
             },
             "HasDisruption": false,
             "HasSpecialEvent": true,
             "HeadBoardRouteNo": "78",
             "InternalRouteNo": 78,
             "IsLowFloorTram": false,
             "IsTTAvailable": true,
             "PredictedArrivalDateTime": "/Date(1615170120000+1100)/",
             "RouteNo": "78",
             "SpecialEventMessage": "Labour Day Public Holiday today: trams run to a Saturday frequency with no Night Network. Info: yarratrams.com.au",
             "TripID": 0,
             "VehicleNo": 291
         }
     ],
     "timeRequested": "/Date(1615167519571+1100)/",
     "timeResponded": "/Date(1615167519649+1100)/",
     "webMethodCalled": "GetNextPredictedRoutesCollection"
 }
""".data(using: .utf8)!
}

func getMockTramSouthStopJsonData() -> Data {
    """
 {
     "errorMessage": null,
     "hasError": false,
     "hasResponse": true,
     "responseObject": [
         {
             "__type": "NextPredictedRoutesCollectionInfo",
             "AirConditioned": false,
             "Destination": "Balaclava",
             "DisplayAC": false,
             "DisruptionMessage": {
                 "DisplayType": "Text",
                 "MessageCount": 0,
                 "Messages": []
             },
             "HasDisruption": false,
             "HasSpecialEvent": true,
             "HeadBoardRouteNo": "78",
             "InternalRouteNo": 78,
             "IsLowFloorTram": false,
             "IsTTAvailable": true,
             "PredictedArrivalDateTime": "/Date(1615168380000+1100)/",
             "RouteNo": "78",
             "SpecialEventMessage": "Labour Day Public Holiday today: trams run to a Saturday frequency with no Night Network. Info: yarratrams.com.au",
             "TripID": 0,
             "VehicleNo": 269
         },
         {
             "__type": "NextPredictedRoutesCollectionInfo",
             "AirConditioned": false,
             "Destination": "Balaclava",
             "DisplayAC": false,
             "DisruptionMessage": {
                 "DisplayType": "Text",
                 "MessageCount": 0,
                 "Messages": []
             },
             "HasDisruption": false,
             "HasSpecialEvent": true,
             "HeadBoardRouteNo": "78",
             "InternalRouteNo": 78,
             "IsLowFloorTram": false,
             "IsTTAvailable": true,
             "PredictedArrivalDateTime": "/Date(1615169280000+1100)/",
             "RouteNo": "78",
             "SpecialEventMessage": "Labour Day Public Holiday today: trams run to a Saturday frequency with no Night Network. Info: yarratrams.com.au",
             "TripID": 0,
             "VehicleNo": 266
         },
         {
             "__type": "NextPredictedRoutesCollectionInfo",
             "AirConditioned": false,
             "Destination": "Balaclava",
             "DisplayAC": false,
             "DisruptionMessage": {
                 "DisplayType": "Text",
                 "MessageCount": 0,
                 "Messages": []
             },
             "HasDisruption": false,
             "HasSpecialEvent": true,
             "HeadBoardRouteNo": "78",
             "InternalRouteNo": 78,
             "IsLowFloorTram": false,
             "IsTTAvailable": true,
             "PredictedArrivalDateTime": "/Date(1615170180000+1100)/",
             "RouteNo": "78",
             "SpecialEventMessage": "Labour Day Public Holiday today: trams run to a Saturday frequency with no Night Network. Info: yarratrams.com.au",
             "TripID": 0,
             "VehicleNo": 263
         }
     ],
     "timeRequested": "/Date(1615167567874+1100)/",
     "timeResponded": "/Date(1615167567936+1100)/",
     "webMethodCalled": "GetNextPredictedRoutesCollection"
 }
""".data(using: .utf8)!
}

func getMockDeviceTokenJsonData()->Data{
    
    return """
        {
            "errorMessage": null,
            "hasError": false,
            "hasResponse": true,
            "responseObject": [
                {
                    "__type": "AddDeviceTokenInfo",
                    "DeviceToken": "80d7fd84-b268-4774-98ee-ec6f33c53dfd"
                }
            ],
            "timeRequested": "/Date(1615100643818+1100)/",
            "timeResponded": "/Date(1615100643833+1100)/",
            "webMethodCalled": "GetDeviceToken"
        }
        """.data(using: .utf8)!
}

func getMockDeviceTokenJsonDataWithErrorMessage()->Data{
    
    return """
        {
            "errorMessage": "Mock Error Message",
            "hasError": false,
            "hasResponse": true,
            "responseObject": [
                {
                    "__type": "AddDeviceTokenInfo",
                    "DeviceToken": "80d7fd84-b268-4774-98ee-ec6f33c53dfd"
                }
            ],
            "timeRequested": "/Date(1615100643818+1100)/",
            "timeResponded": "/Date(1615100643833+1100)/",
            "webMethodCalled": "GetDeviceToken"
        }
        """.data(using: .utf8)!
}

func getMockDeviceTokenValue()->String{
    return "57a24061-54a5-4cf0-97cb-42eab78009d3"
}

func getMockNorthStopId()->String{
    return "4055"
}
func getMockSouthStopId()->String{
    return "4155"
}
