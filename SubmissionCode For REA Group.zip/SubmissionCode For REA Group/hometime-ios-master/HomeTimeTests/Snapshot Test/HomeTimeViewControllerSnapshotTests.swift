//
//  HomeTimeViewControllerSnapshotTests.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import XCTest
import FBSnapshotTestCase
@testable import HomeTime

class HomeTimeViewControllerSnapshotTests: FBSnapshotTestCase {
    
    private var  homeTimeViewController: HomeTimeViewController!
    override  func setUp() {
        super.setUp()
        
        //First Time to setup recordMode to true to record reference Image,
        // then for test to set back recordMode to false
        recordMode = false
        
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        homeTimeViewController = storyboard.instantiateViewController(
            identifier: String(describing: HomeTimeViewController.self))
        CommonLib.defaults = MockUserDefaults()
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        homeTimeViewController.networkManager = NetworkManager()
    }
    
    func test_homeTimeViewController_Screen() throws {
        
        
        let session = MockURLSession()
        session.nextData = getMockTramNorthStopJsonData()
        session.responseCode = 200
        homeTimeViewController.networkManager.session = session
        homeTimeViewController.currentDateTime = getDate()!
        homeTimeViewController.loadViewIfNeeded()
        homeTimeViewController.activityIndicator.isHidden = true
        let exp = expectation(description: "Loading Data")
        if CommonLib.readTokenValue() != nil{
            
            homeTimeViewController.loadTramData(describe: "LoadTramData"){
                exp.fulfill()
            }
           
        }
        waitForExpectations(timeout: 1,handler: nil)
        
        
        FBSnapshotVerifyViewController(homeTimeViewController)
    }
    
    // Fix the showing Data ,otherwise everytime load screen current datetime is different, then no way to compare
    
    private func  getDate()->Date?{
        
        //2021-03-08 01:30:20 +0000
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.locale = Locale.current
        return dateFormatter.date(from: "2021-03-08T01:30:20")
    }
    
}
