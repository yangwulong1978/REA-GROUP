//
//  HomeTimeIntegrationTest.swift
//  HomeTimeTests
//
//  Copyright © 2021 REA. All rights reserved.
//

import XCTest
import SwiftyJSON
@testable import HomeTime
class HomeTimeIntegrationTests: XCTestCase {
    
    static let token = CommonLib.tokenKey
    private var homeTimeViewController:HomeTimeViewController!
    override  func setUp() {
        CommonLib.defaults = MockUserDefaults()
        CommonLib.saveTokenValue(tokenValue: getMockDeviceTokenValue())
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        homeTimeViewController = storyboard.instantiateViewController(
            identifier: String(describing: HomeTimeViewController.self))
        homeTimeViewController.networkManager = NetworkManager()
    }
    
    override  func tearDown() {
        
        homeTimeViewController = nil
    }
    
    func test_callWebservice_getDeviceToken() throws{
        
        
        let exp = expectation(description: "fetch DeviceToken")
        homeTimeViewController.networkManager.getDeviceToken(){
            exp.fulfill()
        }
        waitForExpectations(timeout: 10)
        let token = CommonLib.readTokenValue()
        
        XCTAssertTrue(token != nil && token!.count > 0)
        
    }
   
    func test_callWebservice_loadTramData_GetBothSouthAndNorthTramData() throws{
        
       // let token = CommonLib.readTokenValue()
        homeTimeViewController.loadViewIfNeeded()
        
        let exp = expectation(description: "fetch northTramData")
        homeTimeViewController.loadTramData(describe: "LoadTramData"){
            exp.fulfill()
        }
        
        waitForExpectations(timeout: 10,handler: nil)
        XCTAssertTrue(homeTimeViewController.northTramsArr.count > 0 && homeTimeViewController.southTramsArr.count > 0  )
        
    }
    
    
    func test_callWebservice_loadStopTramData_GetNorthTramData() throws{
        
        let token = CommonLib.readTokenValue()
        homeTimeViewController.loadViewIfNeeded()
        
        let exp = expectation(description: "fetch northTramData")
        homeTimeViewController.loadStopTramData(stop:STOP.north.rawValue,stopId: homeTimeViewController.networkManager.getNorthStopId(), token: token!){
            exp.fulfill()
        }
    
        waitForExpectations(timeout: 10,handler: nil)
        XCTAssertTrue(homeTimeViewController.northTramsArr.count > 0)
        
    }
    
    func test_callWebservice_loadStopTramData_GetSouthTramData() throws{
        let token = CommonLib.readTokenValue()
        homeTimeViewController.loadViewIfNeeded()
        
        let exp = expectation(description: "fetch southTramData")
        homeTimeViewController.loadStopTramData(stop:STOP.south.rawValue,stopId: homeTimeViewController.networkManager.getSouthStopId(), token: token!){
            exp.fulfill()
        }
        
        waitForExpectations(timeout: 10,handler: nil)
        XCTAssertTrue(homeTimeViewController.southTramsArr.count > 0)
        
    }
    
    func test_SouthAndNorthStopTramData_Cleared() throws{
        
        //let token = CommonLib.readTokenValue()
        homeTimeViewController.loadViewIfNeeded()
        
        let exp = expectation(description: "fetch northTramData")
        homeTimeViewController.loadTramData(describe: "LoadTramData"){
            exp.fulfill()
            self.homeTimeViewController.clearTramData()
        }
        
        waitForExpectations(timeout: 10,handler: nil)
        XCTAssertTrue(homeTimeViewController.northTramsArr.count == 0 && homeTimeViewController.southTramsArr.count == 0  )
        
    }
    
    func test_SouthStopTramData_Cleared() throws{
        
        let token = CommonLib.readTokenValue()
        homeTimeViewController.loadViewIfNeeded()
        
        let exp = expectation(description: "fetch SouthTramData")
        homeTimeViewController.loadStopTramData(stop:STOP.south.rawValue,stopId: homeTimeViewController.networkManager.getSouthStopId(), token: token!){
            exp.fulfill()
            self.homeTimeViewController.clearTramData()
            
        }
        waitForExpectations(timeout: 10,handler: nil)
        XCTAssertTrue(homeTimeViewController.southTramsArr.count == 0 )
    }
    
    func test_NorthStopTramData_Cleared() throws{
        
        let token = CommonLib.readTokenValue()
        homeTimeViewController.loadViewIfNeeded()
        
        let exp = expectation(description: "fetch NorthTramData")
        homeTimeViewController.loadStopTramData(stop:STOP.north.rawValue,stopId: homeTimeViewController.networkManager.getNorthStopId(), token: token!){
            exp.fulfill()
            self.homeTimeViewController.clearTramData()
            
        }
        waitForExpectations(timeout: 10,handler: nil)
        XCTAssertTrue(homeTimeViewController.northTramsArr.count == 0)
        
    }
    
}
