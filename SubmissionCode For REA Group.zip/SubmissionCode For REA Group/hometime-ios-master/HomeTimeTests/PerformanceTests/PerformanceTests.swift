//
//  PerformanceTests.swift
//  HomeTimeTests
//
//  Created by yang wulong on 11/3/21.
//  Copyright © 2021 REA. All rights reserved.
//

import XCTest

@testable import HomeTime
class PerformanceTests: XCTestCase {
    
    
    func test_HomeTimeViewController_LoadData() throws{
        
        measure {
            
            CommonLib.defaults = MockUserDefaults()
            CommonLib.saveTokenValue(tokenValue: "57a24061-54a5-4cf0-97cb-42eab78009d3")
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let homeTimeViewController:HomeTimeViewController = storyboard.instantiateViewController(
                identifier: String(describing: HomeTimeViewController.self))
            homeTimeViewController.loadViewIfNeeded()
            homeTimeViewController.networkManager = NetworkManager()
            
            let exp = expectation(description: "fetchramData")
            homeTimeViewController.loadTramData(describe: "LoadTramData"){
                    exp.fulfill()
            }
        
            wait(for: [exp], timeout: 10)
        }
      
    }
}
