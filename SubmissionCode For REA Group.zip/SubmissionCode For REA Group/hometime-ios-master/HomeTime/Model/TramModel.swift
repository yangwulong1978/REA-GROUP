//
//  TramModel.swift
//  HomeTime
//
//  Copyright © 2021 REA. All rights reserved.
//

import Foundation

public class TramModel{
    var StopId:String?
    var RoutNo:String?
    var PredictedArrivalDateTime: String?
    var VehicleNo:String?
    var Destination: String?
    var TimeLeft:String?
    
}
