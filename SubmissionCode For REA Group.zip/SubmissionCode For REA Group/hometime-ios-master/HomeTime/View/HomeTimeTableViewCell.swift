//
//  HomeTimeTableViewCell.swift
//  HomeTime
//
//  Copyright © 2021 REA. All rights reserved.
//

import UIKit

class HomeTimeTableViewCell: UITableViewCell {
    
    @IBOutlet weak var arrivalTimeLbl: UILabel!
    @IBOutlet weak var timeLeftLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
