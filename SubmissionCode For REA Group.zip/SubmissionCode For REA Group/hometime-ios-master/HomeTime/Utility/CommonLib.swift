//
//  CommonLib.swift
//  HomeTime
//
//  Copyright © 2021 REA. All rights reserved.
//

import Foundation
import UIKit

protocol UserDefaultsProtocol {
    func set(_ value: Any?, forKey: String)
    func string(forKey defaultName: String) -> String?
}

extension UserDefaults: UserDefaultsProtocol {
}

public class CommonLib{
    
    static let tokenKey = "DEVICETOKENKEY"
    static var defaults:UserDefaultsProtocol = UserDefaults.standard
    
    static func saveTokenValue(tokenValue:String){
        
        defaults.set(tokenValue, forKey: tokenKey)
    }
    static func readTokenValue()->String?{
        
        return defaults.string(forKey: tokenKey)
    }
    
    static func uiAlertPopupController(title: String?,message:String?,viewController: AnyObject?,displaySeconds:Double,completion:@escaping ()->Void){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        viewController!.present(alert, animated: true, completion: nil)
        
        let delayTime = DispatchTime.now() + Double(Int64(displaySeconds * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: delayTime){
            if  viewController != nil  {
                viewController?.dismiss(animated: true, completion: nil)
                
                completion()
            }
            
        }
        
    }
    
    //Mark: DotNetDateConverter
    
    static func dateFromDotNetFormattedDateString(_ string: String) -> Date? {
        guard let startRange = string.range(of: "("),
              let endRange = string.range(of: "+") else { return nil }
        
        let lowBound = string.index(startRange.lowerBound, offsetBy: 1)
        let range = lowBound..<endRange.lowerBound
        
        let dateAsString = string[range]
        guard let time = Double(dateAsString) else { return nil }
        let unixTimeInterval = time / 1000
        
        return Date(timeIntervalSince1970: unixTimeInterval)
    }
    
    static func formattedDateFromString(_ string: String) -> String {
        let date = dateFromDotNetFormattedDateString(string)
        if date == nil{
            return ""
        }
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm a"
        return formatter.string(from: date!)
    }
    static func minutesBetweenDates(_ predicteArrivalDateTimeStr: String,_ currentDateTime:Date) -> String {
        
        //get both times sinces refrenced date and divide by 60 to get minutes
        let predicteArrivalDateTime = dateFromDotNetFormattedDateString(predicteArrivalDateTimeStr)
        if predicteArrivalDateTime == nil {
            
            return ""
        }
        let currentDateTime = currentDateTime
        let newDateMinutes = predicteArrivalDateTime!.timeIntervalSinceReferenceDate/60
        let oldDateMinutes = currentDateTime.timeIntervalSinceReferenceDate/60
        let diffMin  = abs(Int( newDateMinutes - oldDateMinutes))
        
        //then return the difference
        return  diffMin < 10 ? "0\(diffMin) min":"\(diffMin) min"
    }
}
