//
//  APIManager.swift
//  HomeTime
//
// 
//  Copyright © 2021 REA. All rights reserved.
//

import Foundation
import SwiftyJSON
class NetworkManager{
    
    var baseURL = "http://ws3.tramtracker.com.au"
    var session: URLSessionProtocol = URLSession.shared
    
    
    //Mark: manage Webservice URL
    
    func getDeviceTokenUrl()->URL{
        return   URL(string:baseURL + "/TramTracker/RestService/GetDeviceToken/?aid=TTIOSJSON&devInfo=HomeTimeiOS")!
    }
    func getNextPredictedRoutesCollectionUrl(stopId: String, token: String) -> URL {
        let urlTemplate = baseURL + "/TramTracker/RestService/GetNextPredictedRoutesCollection/{STOP_ID}/78/false/?aid=TTIOSJSON&cid=2&tkn={TOKEN}"
        return  URL(string:  urlTemplate.replacingOccurrences(of: "{STOP_ID}", with: stopId).replacingOccurrences(of: "{TOKEN}", with: token))!
    }
    
    func getNorthStopId()->String{
        return "4055"
    }
    func getSouthStopId()->String{
        return "4155"
    }
    
    //Mark: Call Web service
    func getDeviceToken(completion:@escaping ()->Void){
        
        
        let tokenURL = getDeviceTokenUrl()
        let httpClient =  HttpClient(session: session)
        httpClient.get(url: tokenURL){( data, response,error) in
            if error != nil {
                print(error as Any)
                completion()
                return
            }
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else {
                print(response as Any)
                completion()
                return
            }
            if data != nil  {
                if JSON(data!)["errorMessage"].stringValue != "" {
                    // OH NO, data error occurred...
                    let errorMessage = JSON(data!)["errorMessage"].stringValue
                    print(errorMessage)
                   
                    completion()
                    return
                }
                let token = JSON(data!)["responseObject"][0]["DeviceToken"].stringValue
                CommonLib.saveTokenValue(tokenValue: token)
                
            }
            completion()
            
        }
    }
    
    func loadStopTramData(stop:String,stopId:String,token:String,complete:@escaping (Data?, URLResponse?, Error?) ->Void){
        
        let stopUrl = getNextPredictedRoutesCollectionUrl(stopId: stopId, token: token)
        let httpClient =  HttpClient(session: session)
        httpClient.get(url: stopUrl){ ( data, response,error) in
            complete(data,response,error)
        }
        
    }
    
    
}

