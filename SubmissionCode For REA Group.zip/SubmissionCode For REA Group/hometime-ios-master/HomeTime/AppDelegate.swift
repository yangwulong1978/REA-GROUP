//
//  Copyright © 2017 REA. All rights reserved.
//

import UIKit
import SwiftyJSON
//@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        print("<< Launching with testing app delegate")
        // fetch deviceToken ,if not exist
        if CommonLib.readTokenValue() == nil {
            let netWorkManager = NetworkManager()
            netWorkManager.getDeviceToken(){}
        }
        
        
        
        
        return true
    }
    
}
