//
//  Copyright © 2017 REA. All rights reserved.
//

import UIKit
import SwiftyJSON

enum STOP:String{
    case north = "NORTH"
    case south = "SOUTH"
}
class HomeTimeViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet var tramTimeTable: UITableView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var clearBarButton: UIBarButtonItem!
    @IBOutlet weak var refreshBarButton: UIBarButtonItem!
    
    var northTramsArr = [TramModel]()
    var southTramsArr = [TramModel]()
    
    var currentDateTime = Date()
    var hasFetchedToken :Bool = false
    var networkManager = NetworkManager()
    
    //refresh data every 5 minutes
    var withTimeInterval = 60*5 
    
    //Test purpose
    var hasSelectedRow = false
    var loading = false
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetupScreen()
        clearTramData()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        loadTramData(describe:"LoadTramData"){}
        //scheduledTimerToCallWebService(second: withTimeInterval){}
    }
    func initialSetupScreen(){
        
        hasSelectedRow = false
        tramTimeTable.delegate = self
        tramTimeTable.dataSource = self
        tramTimeTable.tableFooterView = UIView()
        
        registerTableCell()
        
        activityIndicator.hidesWhenStopped = true
        activityIndicator.stopAnimating()
        activityIndicator.transform = CGAffineTransform(scaleX: 2, y: 2)
        
    }
    
    func registerTableCell(){
        tramTimeTable.register(UINib(nibName: "HomeTimeTableViewCell", bundle: nil), forCellReuseIdentifier: "HomeTimeTableViewCell")
    }
    @IBAction func clearButtonTapped(_ sender: UIBarButtonItem) {
        clearTramData()
    }
    
    @IBAction func refreshButtonTapped(_ sender: UIBarButtonItem) {
        loading = true
        clearTramData()
        loadTramData(describe: "LoadTramData"){}
    }
    
    
}

// MARK: - Operate Tram Data

extension HomeTimeViewController {
    
    func clearTramData() {
        northTramsArr.removeAll()
        southTramsArr.removeAll()
        hasSelectedRow = false
        DispatchQueue.main.async {
            self.tramTimeTable.reloadData()
        }
    }
    
    func loadTramData(describe:String,complete:@escaping ()->Void) {
        
        if let token = CommonLib.readTokenValue(){
            loadTramDataByToken(token: token){
                complete()
            }
        }else{
            
            fetchDeviceToken(describe: "FetchToken"){
                complete()
            }
        }
    }
    
    func fetchDeviceToken(describe:String,complete:@escaping ()->Void){
        
        //if token has not been successfully fetched. refetch again.
        networkManager.getDeviceToken(){
            self.hasFetchedToken = true
            if let token = CommonLib.readTokenValue(){
                self.loadTramDataByToken(token: token){}
            }else{
                CommonLib.uiAlertPopupController(title: "Information Message", message: "OH,Something wrong in the server please click  load button try again!", viewController: self, displaySeconds: 2){}
            }
            complete()
        }
    }
    func loadTramDataByToken(token:String,complete:@escaping ()->Void){
        let group = DispatchGroup()
        
        group.enter()
        loadStopTramData(stop:STOP.north.rawValue,stopId: networkManager.getNorthStopId(), token: token){
            group.leave()
        }
        
        group.enter()
        loadStopTramData(stop:STOP.south.rawValue,stopId: networkManager.getSouthStopId(), token: token){
            
            group.leave()
        }
        
        // wait both asynchronous Completion
        group.notify(queue: DispatchQueue.global()) {
            print("Completed work:")
            complete()
            
        }
    }
    
    func loadStopTramData(stop:String,stopId:String,token:String,complete:@escaping () ->Void){
        activityIndicator.startAnimating()
        
        networkManager.loadStopTramData(stop:stop , stopId: networkManager.getNorthStopId(), token: token){
            (data,response,error) in
            
            if error != nil {
                // OH NO! An error occurred...
                print(error as Any)
                CommonLib.uiAlertPopupController(title: "Information Message", message: "OH,Something wrong  \(String(describing: error))", viewController: self, displaySeconds: 2){}
                
                complete()
                return
            }
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else {
                //OH NO! An server error occurred...
                print(response as Any)
                CommonLib.uiAlertPopupController(title: "Information Message", message: "OH,Something wrong  \(String(describing: response))", viewController: self, displaySeconds: 2){}
                
                complete()
                return
            }
            
            if data != nil  {
                if JSON(data!)["errorMessage"].stringValue != "" {
                    // OH NO, data error occurred...
                    let errorMessage = JSON(data!)["errorMessage"].stringValue
                    
                    print(errorMessage)
                    CommonLib.uiAlertPopupController(title: "Information Message", message: "OH,Something wrong  \(errorMessage)", viewController: self, displaySeconds: 2){}
                    complete()
                    return
                }
                let tramJsonData = JSON(data!)["responseObject"]
                self.parseTramJsonData(stop: stop,stopId: stopId, tramJsonData: tramJsonData)
                
            }
            complete()
        }
        
    }
    
    func parseTramJsonData(stop:String,stopId:String,tramJsonData:JSON){
      
        var tempDataArr = [TramModel]()
        if tramJsonData.count > 0 && tramJsonData.null == nil{
            for i in 0..<tramJsonData.count{
                let tramModel = TramModel()
                
                tramModel.Destination = tramJsonData[i]["Destination"].stringValue
                let predictDateTimeStr =  tramJsonData[i]["PredictedArrivalDateTime"].stringValue
                
                if predictDateTimeStr.isEmpty == false  {
                    tramModel.PredictedArrivalDateTime = CommonLib.formattedDateFromString(predictDateTimeStr)
                    
                    let diffMin = CommonLib.minutesBetweenDates(predictDateTimeStr,currentDateTime)
                    tramModel.TimeLeft = diffMin
                }
                else{
                    tramModel.PredictedArrivalDateTime = ""
                    tramModel.TimeLeft = ""
                }
                tramModel.StopId = stopId
                tramModel.RoutNo = tramJsonData[i]["RoutNo"].stringValue
                tramModel.VehicleNo = tramJsonData[i]["VehicleNo"].stringValue
                tempDataArr.append(tramModel)
            }
            
            if stop == STOP.north.rawValue{
                northTramsArr.removeAll()
                northTramsArr = tempDataArr
            }else{
                southTramsArr.removeAll()
                southTramsArr = tempDataArr
            }
            DispatchQueue.main.async {
                self.tramTimeTable.reloadData()
                self.activityIndicator.stopAnimating()
                self.loading = false
            }
            //            print("northTramsARrr", northTramsArr.count )
            //            print("southTramsARrr", southTramsArr.count )
        }
    }
    
}


// MARK - UITableViewEvent

extension HomeTimeViewController {
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "HomeTimeTableViewCell", for: indexPath) as! HomeTimeTableViewCell
        
        if indexPath.section == 0 && northTramsArr.count > 0 {
            cell.arrivalTimeLbl.text = northTramsArr[indexPath.row].PredictedArrivalDateTime!
            cell.timeLeftLbl.text = northTramsArr[indexPath.row].TimeLeft!
        }
        else if indexPath.section == 1 && southTramsArr.count > 0 {
            cell.arrivalTimeLbl.text = southTramsArr[indexPath.row].PredictedArrivalDateTime!
            cell.timeLeftLbl.text = southTramsArr[indexPath.row].TimeLeft!
        }
        
        return cell;
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if (section == 0){
            let count = northTramsArr.count
            return count
        }
        else{
            let count = southTramsArr.count
            return  count
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if northTramsArr.count > 0 && section == 0 {
            return "North"
        }
        else if southTramsArr.count > 0 && section == 1 {
            return "South"
        }
        else {
            return  "" 
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print("did Select triggered")
        hasSelectedRow = true
        //            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        //            let nextVc = storyBoard.instantiateViewController(withIdentifier: "HomeTimeDetailViewController") as! HomeTimeDetailViewController
        //
        //            var tramModel = TramModel()
        //            if indexPath.section == 0{
        //    
        //                tramModel = northTramsArr[indexPath.row]
        //            }else if indexPath.section == 1{
        //                tramModel = southTramsArr[indexPath.row]
        //            }
        //            nextVc.tramModel = tramModel
        //            self.navigationController?.pushViewController(nextVc, animated: true)
    }
}

// MARK - UITableViewEvent

//extension HomeTimeViewController {
//
//
//    func scheduledTimerToCallWebService(second:Int, complete:@escaping () -> Void){
//
//        Timer.scheduledTimer(withTimeInterval: TimeInterval(second), repeats: true){ [self]_ in
//
//            print(" in the timer ")
//            self.loadTramData(){}
//            complete()
//        }
//    }
//}
