//
//  main.swift
//  HomeTime
//
//  Copyright © 2021 REA. All rights reserved.
//

import Foundation
import UIKit

let appDelegateClass: AnyClass =
    NSClassFromString("TestingAppDelegate") ?? AppDelegate.self
UIApplicationMain(
    CommandLine.argc,
    CommandLine.unsafeArgv,
    nil,
    NSStringFromClass(appDelegateClass))
