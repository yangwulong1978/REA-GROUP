//
//  PerformanceTests.swift
//  HomeTimeUITests
//
//  Copyright © 2021 REA. All rights reserved.
//

import XCTest

class PerformanceTests: XCTestCase {
    
    
    override class func setUp() {
        
    }
    
    func test_HomeTimeViewController_LaunchPerformance() throws {
        if #available(macOS 10.15, iOS 13.0, tvOS 13.0, *) {
            // This measures how long it takes to launch your application.
            measure(metrics: [XCTApplicationLaunchMetric()]) {
                XCUIApplication().launch()
            }
        }
    }
    
    func test_HomeTimeViewController_tramTimesTable_LoadData() throws{
     
        measure {
            let app = XCUIApplication()
            app.launch()
            let homeTimeNavigationBar = app.navigationBars["Home Time"]
            let refreshButton = homeTimeNavigationBar.buttons["Refresh"]
            refreshButton.tap()
            let _ = XCUIApplication().tables

        }
    }
    
}
