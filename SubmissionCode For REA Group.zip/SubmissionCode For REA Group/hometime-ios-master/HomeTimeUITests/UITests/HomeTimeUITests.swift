//
//  HomeTimeUITests.swift
//  HomeTimeUITests
//
//  Copyright © 2021 REA. All rights reserved.
//

import XCTest


class HomeTimeUITests: XCTestCase {
    
    let app = XCUIApplication()
    override func setUpWithError() throws {
        continueAfterFailure = false
        app.launch()
    }
    
    override func tearDownWithError() throws {
        app.terminate()
    }
    
    func test_HomeTimeViewScreen_Loaded() throws{
        
        let homeTimeNavigationBar = XCUIApplication().navigationBars["Home Time"]
        XCTAssertTrue(homeTimeNavigationBar.waitForExistence(timeout:10.0))
    }
    func test_HomeTimeViewController_ClearBarButton_Exists() throws{
        let homeTimeNavigationBar = app.navigationBars["Home Time"]
        XCTAssertTrue(homeTimeNavigationBar.buttons["Clear"].waitForExistence(timeout:10.0))
    }
    func test_HomeTimeViewController_LoadBarButton_Exists() throws{
        let homeTimeNavigationBar = app.navigationBars["Home Time"]
        XCTAssertTrue(homeTimeNavigationBar.buttons["Refresh"].waitForExistence(timeout:10.0))
    }
    
    func test_HomeTimeViewController_LoadBarButton_LoadData() throws{
        let homeTimeNavigationBar = app.navigationBars["Home Time"]
        let loadButton = homeTimeNavigationBar.buttons["Refresh"]
        loadButton.tap()
        let tablesQuery = XCUIApplication().tables
        XCTAssertTrue( tablesQuery.cells.staticTexts["Arrival Time:"].waitForExistence(timeout:10.0))
    }
    func test_HomeTimeViewController_ClearBarButton_ClearData() throws{
        let homeTimeNavigationBar = app.navigationBars["Home Time"]
        let refreshButton = homeTimeNavigationBar.buttons["Refresh"]
        refreshButton.tap()
        let tablesQuery = XCUIApplication().tables
        let exp = expectation(description: "Loading data")
      
        let delayTime = DispatchTime.now() + Double(Int64(10 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
       
        // wait to load data
        DispatchQueue.main.asyncAfter(deadline: delayTime){
            exp.fulfill()
            
        }
        //give time to Load data
        waitForExpectations(timeout: 10)
        homeTimeNavigationBar.buttons["Clear"].tap()
        let exp2 = expectation(description: "Clear data")
        exp2.fulfill()
        //give time to clear data from screen
        waitForExpectations(timeout: 2)
        XCTAssertFalse( tablesQuery.cells.staticTexts["Arrival Time:"].exists)
    }
    
    func test_HomeTimeViewController_tableSections_Loaded(){
        let homeTimeNavigationBar = app.navigationBars["Home Time"]
        let refreshButton = homeTimeNavigationBar.buttons["Refresh"]
        //tap refresh button to load data.
        refreshButton.tap()
        let tablesQuery = XCUIApplication().tables
        let exp = expectation(description: "Loading data")
        
        let delayTime = DispatchTime.now() + Double(Int64(10 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
       
        // wait to load data
        DispatchQueue.main.asyncAfter(deadline: delayTime){
            exp.fulfill()
            
        }
        waitForExpectations(timeout: 10)
        
        //check wether two section has been loaded.
        XCTAssertTrue(tablesQuery.staticTexts["South"].waitForExistence(timeout:10.0) &&  tablesQuery.staticTexts["North"].waitForExistence(timeout:10.0))
        
    }
    
    
    
}
